const person = {
  name: "Wes",
  last: "Bos",
};

export default person;

export const dog = "Snickers";
export const food = "pizza";
export function eat() {
  console.log("chomp chomp");
}
